run as administrator (beta crack)

error?
https://slproweb.com/products/Win32OpenSSL.html